package com.shop.My_Shop.Repository;

import com.shop.My_Shop.Entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Customer_Repository extends JpaRepository<Customer,Integer> {
}
