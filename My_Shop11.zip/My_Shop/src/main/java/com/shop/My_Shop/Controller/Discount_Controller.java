package com.shop.My_Shop.Controller;

import com.shop.My_Shop.Entity.Discount;
import com.shop.My_Shop.Repository.Discount_Repository;
import com.shop.My_Shop.Repository.Product_Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class Discount_Controller {
    @Autowired
    private Discount_Repository dr;

    @Autowired
    private Product_Repository pr;
    //-------------------------------------------------------

    //To create Discount Coupon Code
    @PostMapping("/create/discount")
    public String Create_Discount(@RequestBody Discount d){
        d.getDiscount_code();
        d.getValue();
        d.getCoupon_type();
        dr.save(d);
        return "Discount Created Successfully";
    }

    //------------------------------------------------------

    //To Delete Particular Coupon Code
    @DeleteMapping("delete/discount/{Discount_code}")
    public String Delete_Discount(@PathVariable String Discount_code){
        dr.deleteById(Discount_code);
        return "Discount Coupon deleted Successfully";

    }
    //--------------------------------------------------------

    //To get all Discount Coupon Codes
    @GetMapping("/list/all_discount")
    public List<Discount> GetAllDiscount(){
        return dr.findAll();
    }
//-----------------------------------------------------------

    //To Update Particular Coupon Code
    @PutMapping("/update/discount/{Discount_code}")
    public String Update_Discount(@PathVariable String Discount_code,@RequestBody Discount d){
        Discount discountlist=dr.findById(Discount_code).orElse(null);
        discountlist.setDiscount_code(d.getDiscount_code());

        discountlist.setValue(d.getValue());
        dr.save(discountlist);
        return "Discount Coupon Updated Successfully";
    }
}
