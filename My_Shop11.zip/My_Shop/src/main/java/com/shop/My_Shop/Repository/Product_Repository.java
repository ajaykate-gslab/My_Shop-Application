package com.shop.My_Shop.Repository;

import com.shop.My_Shop.Entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Product_Repository extends JpaRepository<Product,Integer> {
}
