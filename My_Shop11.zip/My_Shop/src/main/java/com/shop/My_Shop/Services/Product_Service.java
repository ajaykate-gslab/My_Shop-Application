package com.shop.My_Shop.Services;

import com.shop.My_Shop.Entity.Product;
import com.shop.My_Shop.Repository.Product_Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class Product_Service {
    @Autowired
    private Product_Repository pr;

    public void insert(Product p){
        pr.save(p);
    }

    public List<Product> get_all_product(){
        List<Product> l=pr.findAll();
        for(Product p :l){
            System.out.println(p);
        }
        return l;
    }

    public String update_product(Product p,int product_id){
        p.setProduct_id(product_id);
        pr.save(p);
        return "product updated";
    }


}
