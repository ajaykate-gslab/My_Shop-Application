package com.shop.My_Shop.Repository;

import com.shop.My_Shop.Entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Order_Repository extends JpaRepository <Order,Integer>{
}
