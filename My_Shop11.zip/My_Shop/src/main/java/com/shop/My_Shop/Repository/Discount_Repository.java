package com.shop.My_Shop.Repository;

import com.shop.My_Shop.Entity.Discount;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Discount_Repository extends JpaRepository<Discount,String> {
}
