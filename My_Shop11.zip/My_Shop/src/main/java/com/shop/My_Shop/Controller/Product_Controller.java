package com.shop.My_Shop.Controller;

import com.shop.My_Shop.Entity.Product;
import com.shop.My_Shop.Repository.Product_Repository;
import com.shop.My_Shop.Services.Product_Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class Product_Controller {
    @Autowired
    private Product_Service ps;

    @Autowired
    private Product_Repository pr;

    Product p=new Product();

    @PostMapping("/insert")
    public String insert_Controller(@RequestBody Product p){
        p.getProduct_id();
        p.getProduct_name();
        p.getProduct_price();
        p.getBrand();
        p.getProduct_colour();
        pr.save(p);
        return "Product Inserted";
    }
//---------------------------------------------------------
    @GetMapping("/show")
    public List<Product> show_controller(){
        List<Product> l=ps.get_all_product();
        return l;
    }
//----------------------------------------------------------
    /*@PutMapping("/update/{product_id}")
    public String update_controller(@RequestBody Product p, @PathVariable("product_id") int product_id){

        return "Product successfully updated";
    }*/
//--------------------------------------------------------
    @PutMapping("/update/product/{product_id}")
    public String update_product_controller(@PathVariable int product_id, @RequestBody Product p){
        Product productList = pr.findById(product_id).orElse(null);
        productList.setProduct_id(p.getProduct_id());
        productList.setProduct_name(p.getProduct_name());
        productList.setProduct_price(p.getProduct_price());
        productList.setProduct_colour(p.getProduct_colour());
        pr.save(productList);
        return "Product Updated successfully";
    }

    //-----------------------------------------------------------
    @DeleteMapping("/delete/product/{product_id}")
    public String delete_product_controller(@PathVariable int product_id){
        pr.deleteById(product_id);
        return "Product deleted successfully";
    }




}
