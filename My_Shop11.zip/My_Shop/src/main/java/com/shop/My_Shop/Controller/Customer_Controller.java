package com.shop.My_Shop.Controller;

import com.shop.My_Shop.Entity.Customer;
import com.shop.My_Shop.Entity.Discount;
import com.shop.My_Shop.Entity.Order;
import com.shop.My_Shop.Entity.Product;
import com.shop.My_Shop.Repository.Customer_Repository;
import com.shop.My_Shop.Repository.Discount_Repository;
import com.shop.My_Shop.Repository.Order_Repository;
import com.shop.My_Shop.Repository.Product_Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.swing.text.html.Option;
import java.util.*;

@RestController
public class Customer_Controller {

    @Autowired
    private Customer_Repository cr;

    @Autowired
    private Product_Repository pr;

    @Autowired
    private Order_Repository or;

    @Autowired
    private Discount_Repository dr;

    @PostMapping("/create/customer")
    public String create_customer(@RequestBody Customer c){
        c.getCustomer_id();
        c.getCustomer_name();
        c.getAddress();
        c.getEmail();
        c.getMobile();

        cr.save(c);
        return "Customer created";
    }

    @PostMapping("buy/product/{product_id}/{discount_code}")
    public String buy_product(@PathVariable int product_id,@PathVariable String discount_code,@RequestBody Order o){
        Optional<Product> pro=pr.findById(product_id);
        Optional<Discount> dis=dr.findById(discount_code);

        Product p=new Product();
        Discount d=new Discount();
        Customer c=new Customer();

        if(pro.isPresent() && dis.isPresent()){
            Product pp=(Product)pro.get();
            Discount dd=(Discount)dis.get();

            o.setProduct_id(pp.getProduct_id());
            o.setCoupon_Type(dd.getCoupon_type());
            o.setDiscount_code(dd.getDiscount_code());

            o.getCustomer_name();


            if(dd.getCoupon_type().equals("FLAT")){
                double y =pp.getProduct_price()-dd.getValue();
                o.setFinal_price(y);

            }
            else if("PERCENTAGE".equals(dd.getCoupon_type()))
            {
                double y=pp.getProduct_price()*dd.getValue()/100;
                o.setFinal_price(y);

            }
            or.save(o);
        }
        else {
            return "Product Out Of Stock...!!!";

        }

        return "order placed ";
    }

//------------------------------------------------------------------


    // To Cancel Order
    @DeleteMapping("cancel/order/{product_id}")
    public String Cancel_Product(@PathVariable int product_id){
        or.deleteById(product_id);
        return "Product Successfully cancelled";
    }

    }
